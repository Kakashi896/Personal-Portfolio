import React from 'react'
import AppRoutes from '../src/AppRoutes'

const App = () => {
  return (
    <>
     <AppRoutes/> 
    </>
  )
}

export default App
