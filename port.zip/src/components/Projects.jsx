import React from 'react';
import { RiProjectorFill } from "react-icons/ri";
import Arogyam from '../assets/Arogyam.png';
import DocsMini from '../assets/DocsMini.png';
import Portfolio from '../assets/Portfolio.png';

const Projects = () => {
  const projects = [
    {
      title: "Arogyam",
      description: "Mental health wellness website",
      image: Arogyam
    },
    {
      title: "DocsMini",
      description: "A document organizer model",
      image: DocsMini
    },
    {
      title: "Portfolio",
      description: "A showcase of my work",
      image: Portfolio
    }
  ];

  return (
    <section id="projects" className="min-h-screen p-6 sm:p-10 bg-white">
      <div>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 ml-2">
          <RiProjectorFill className="text-4xl text-blue-500 mt-1" />
          <h1 className="text-4xl sm:text-5xl font-mono">Projects</h1>
          <div className="w-full sm:w-[70vw] h-[2px] mt-2 bg-blue-400"></div>
        </div>

        <div className="mt-16 space-y-10">
          {projects.map((item, index) => (
            <div
              key={index}
              className="relative group flex flex-col sm:flex-row items-start sm:items-center border border-zinc-200 w-full sm:w-[85vw] p-6 rounded-lg bg-zinc-100 hover:bg-zinc-200 transition-all duration-300"
            >
              <div className="absolute right-6 top-1/2 transform -translate-y-1/2 w-[60vw] sm:w-[30vw] h-auto hidden group-hover:block z-10">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-contain object-center rounded-xl shadow-xl"
                />
              </div>

              <h1 className="text-3xl sm:text-5xl text-blue-500">
                {item.title}
                <span className="text-black ml-3">-</span>
              </h1>
              <h2 className="text-xl sm:text-3xl mt-3 sm:mt-2 ml-0 sm:ml-5 text-zinc-700">
                {item.description}
              </h2>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
