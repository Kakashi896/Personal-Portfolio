import React from 'react';
import { FcAbout } from "react-icons/fc";
import { BsPerson } from "react-icons/bs";
import { CiFaceSmile } from "react-icons/ci";
import { FaGithub, FaLinkedin } from "react-icons/fa";
import { Link } from 'react-scroll';

const About = () => {
  const sender = [
    "Hi Shivam! how are you ?",
    "Got it! Could you tell me more about yourself",
    "That's amazing! Skill set you have",
    "Can you share your socials?"
  ];

  const shivam = [
    "Hi! I'm doing great and currently looking for a frontend developer role.",
    "I'm a frontend developer based in Agra, India.",
    "My developer journey began in college, where I learned HTML, CSS, and JavaScript.",
    "I then started working with React and explored other JS libraries like Framer Motion and GSAP, as well as utility-first frameworks like Tailwind CSS.",
    "I enjoy building interactive web applications and creating user-friendly interfaces."
  ];

  return (
    <section id="about" className='w-full min-h-screen pb-10'>
      <div className='flex items-center pt-10 gap-2 px-12'>
        <FcAbout className='text-5xl' />
        <h1 className='text-4xl sm:text-5xl font-semibold'>About</h1>
        <div className='flex-grow h-[2px] bg-blue-400 mt-2 ml-4'></div>
      </div>

      <div className='bg-zinc-100 mx-auto mt-10 w-[95%] rounded p-8 space-y-6'>

        {/* Sender 1 */}
        <div className='flex justify-end'>
          <div className='flex items-start'>
            <p className='bg-blue-400 max-w-[75%] sm:max-w-[22vw] font-medium text-white p-3 rounded-md mr-3'>
              {sender[0]}
            </p>
            <BsPerson className='text-2xl sm:text-3xl' />
          </div>
        </div>

        {/* Shivam 1 */}
        <div className='flex items-start'>
          <CiFaceSmile className='text-2xl sm:text-3xl ml-2 mt-1' />
          <p className='bg-zinc-200 max-w-[85%] sm:max-w-[35vw] font-medium p-3 ml-4 rounded-md'>
            {shivam[0]}
          </p>
        </div>

        {/* Sender 2 */}
        <div className='flex justify-end'>
          <div className='flex items-start'>
            <p className='bg-blue-400 max-w-[75%] sm:w-[25vw] font-medium text-white p-3 rounded-md mr-3'>
              {sender[1]}
            </p>
            <BsPerson className='text-2xl sm:text-3xl' />
          </div>
        </div>

        {/* Shivam 2 to 5 */}
        {shivam.slice(1).map((msg, idx) => (
          <div key={idx} className='flex items-start'>
            <CiFaceSmile className='text-2xl sm:text-3xl ml-2 ' />
            <p className='bg-zinc-200 max-w-[90%] sm:max-w-[42vw] font-medium p-3 ml-4 rounded-md '>
              {msg}
            </p>
          </div>
        ))}

        {/* Sender 3 */}
        <div className='flex justify-end'>
          <div className='flex items-start'>
            <p className='bg-blue-400 max-w-[75%] sm:w-[25vw] font-medium text-white p-3 rounded-md mr-3'>
              {sender[2]}
            </p>
            <BsPerson className='text-2xl sm:text-3xl' />
          </div>
        </div>

        {/* Sender 4 */}
        <div className='flex justify-end'>
          <div className='flex items-start'>
            <p className='bg-blue-400 max-w-[75%] sm:w-[25vw] font-medium text-white p-3 rounded-md mr-3'>
              {sender[3]}
            </p>
            <BsPerson className='text-2xl sm:text-3xl' />
          </div>
        </div>

        {/* Socials */}
        <div className='flex items-start mt-6 flex-wrap px-2 pb-5'>
          <CiFaceSmile className='text-2xl sm:text-3xl mt-1' />
          <div className='ml-4 bg-zinc-200 p-4 rounded-md w-full sm:w-[50%] font-medium space-y-2'>
            <div className='flex flex-wrap items-center gap-4'>
              <p>Here are my</p>
              <a
                href='https://github.com/Kakashi896'
                target='_blank'
                rel='noopener noreferrer'
                className='text-blue-500 hover:underline flex items-center gap-1'
              >
                <FaGithub className='text-2xl' /> GitHub
              </a>
              <a
                href='https://www.linkedin.com/in/shivam-bhardwaj-704643326/'
                target='_blank'
                rel='noopener noreferrer'
                className='text-blue-500 hover:underline flex items-center gap-1'
              >
                <FaLinkedin className='text-2xl' /> LinkedIn
              </a>
            </div>
            <p>
              Find more info about me in my
              <a href="/Shivam_Frontend.pdf" download className='text-blue-500 ml-1 hover:underline cursor-pointer'>CV</a>.
              Good Luck 😊
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};

export default About;
