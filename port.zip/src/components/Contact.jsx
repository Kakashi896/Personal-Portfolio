import React, { useState } from 'react';
import { MdContactPage } from "react-icons/md";
import { CgMail } from "react-icons/cg";
import { FaGithub, FaLinkedin } from "react-icons/fa";

const Contact = () => {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handelSubmit = () => {
    setEmail('');
    setMessage('');
  };

  return (
    <section id="contact" className="min-h-screen p-6 sm:p-10 bg-white">
      <div className="flex flex-col items-start sm:items-center">
        <div className="flex flex-col sm:flex-row gap-2 items-start sm:items-center">
          <MdContactPage className="text-4xl sm:text-5xl mt-2 text-blue-500" />
          <h1 className="text-4xl sm:text-6xl font-mono">Contact</h1>
          <div className="w-full sm:w-[70vw] h-[2px]  sm:mt-2 bg-blue-400" />
        </div>
      </div>

      {/* Optional contact form (currently commented) */}
      {/*
      <div className="w-full sm:w-[35vw] m-auto mt-16 p-5 bg-blue-500 rounded-xl">
        <h1 className="text-white text-2xl ml-2">Let's get in touch</h1>
        <input
          type="text"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full pl-5 pr-5 mt-5 rounded-xl py-3 bg-zinc-50 opacity-50 focus:outline-none"
          placeholder="Email"
        />
        <input
          type="text"
          required
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="w-full pl-5 pr-5 mt-5 pt-5 pb-8 rounded-xl bg-zinc-50 opacity-50 focus:outline-none"
          placeholder="Message"
        />
        <button
          onClick={handelSubmit}
          className="w-full py-2 mt-5 rounded-xl bg-white cursor-pointer"
        >
          Message me
        </button>
      </div>
      */}

      <div className="w-full mt-20 flex flex-col sm:flex-row items-start sm:items-center text-lg sm:text-xl gap-4 sm:gap-8 p-4 sm:p-6 font-bold">
        <a
          className="cursor-pointer hover:underline flex items-center"
          href="https://github.com/Kakashi896"
          target="_blank"
          rel="noopener noreferrer"
        >
          <FaGithub className="mr-2 text-2xl text-blue-700" />
          Github
        </a>

        <a
          className="cursor-pointer hover:underline flex items-center"
          href="https://www.linkedin.com/in/shivam-bhardwaj-704643326/"
          target="_blank"
          rel="noopener noreferrer"
        >
          <FaLinkedin className="mr-2 text-2xl text-blue-700" />
          LinkedIn
        </a>

        <p className="flex items-center break-all">
          <CgMail className="mr-2 text-3xl text-blue-700" />
          mrakshatsharma15@gmail.com
        </p>
      </div>
    </section>
  );
};

export default Contact;
